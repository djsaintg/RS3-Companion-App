import { useState, useMemo } from 'react';
import { getF2PQuests, getMembersQuests } from '../data/quests';
import type { Quest, QuestDifficulty } from '../data/quests';

const difficulties: ('All' | QuestDifficulty)[] = ['All', 'Novice', 'Intermediate', 'Experienced', 'Master', 'Grandmaster'];
const diffColors: Record<string, string> = {
  Novice: 'text-emerald-400 bg-emerald-500/10',
  Intermediate: 'text-cyan-400 bg-cyan-500/10',
  Experienced: 'text-yellow-400 bg-yellow-500/10',
  Master: 'text-orange-400 bg-orange-500/10',
  Grandmaster: 'text-red-400 bg-red-500/10',
  Special: 'text-violet-400 bg-violet-500/10',
};

export default function QuestGuide() {
  const [tab, setTab] = useState<'free' | 'members'>('free');
  const [diff, setDiff] = useState<'All' | QuestDifficulty>('All');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Quest | null>(null);

  const base = tab === 'free' ? getF2PQuests() : getMembersQuests();
  const filtered = useMemo(() => base.filter(q => (diff === 'All' || q.difficulty === diff) && (!search || q.name.toLowerCase().includes(search.toLowerCase()) || q.description.toLowerCase().includes(search.toLowerCase()))), [base, diff, search]);
  const availDiffs = useMemo(() => { const s = new Set(base.map(q => q.difficulty)); return difficulties.filter(d => d === 'All' || s.has(d as QuestDifficulty)); }, [base]);

  if (selected) {
    return (
      <div className="animate-fadeIn">
        <button onClick={() => setSelected(null)} className="flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors mb-4 group cursor-pointer">
          <svg className="w-5 h-5 group-hover:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          <span className="text-sm font-medium">Back to Quests</span>
        </button>
        <div className="flex items-start gap-4 mb-5">
          <div className="w-14 h-14 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-2xl shrink-0">📜</div>
          <div>
            <h2 className="text-2xl font-bold text-white font-cinzel">{selected.name}</h2>
            <div className="flex flex-wrap gap-2 mt-1.5">
              <span className={`text-xs px-3 py-1 rounded-full font-semibold ${selected.membership === 'free' ? 'bg-emerald-500/12 text-emerald-400' : 'bg-violet-500/12 text-violet-400'}`}>{selected.membership === 'free' ? '🆓 F2P' : '⭐ Members'}</span>
              <span className={`text-xs px-3 py-1 rounded-full font-semibold ${diffColors[selected.difficulty]}`}>{selected.difficulty}</span>
              <span className="text-xs px-3 py-1 rounded-full bg-white/5 text-gray-300">{selected.questPoints} QP</span>
              <span className="text-xs px-3 py-1 rounded-full bg-white/5 text-gray-300">{selected.length}</span>
              {selected.seriesTag && <span className="text-xs px-3 py-1 rounded-full bg-violet-500/10 text-violet-400">{selected.seriesTag}</span>}
            </div>
          </div>
        </div>
        <p className="text-gray-300 text-sm mb-4 leading-relaxed">{selected.description}</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          <div className="bg-aurora-card border border-aurora-border rounded-lg p-3"><div className="text-xs text-gray-500 mb-1 font-medium">📍 Start Point</div><div className="text-sm text-white">{selected.startPoint}</div></div>
          <div className="bg-aurora-card border border-aurora-border rounded-lg p-3"><div className="text-xs text-gray-500 mb-1 font-medium">📋 Requirements</div><div className="text-sm text-white">{selected.skills.length > 0 ? selected.skills.join(', ') : 'None'}</div></div>
        </div>
        <div className="mb-6">
          <h3 className="text-lg font-bold text-cyan-400 mb-3 font-cinzel flex items-center gap-2"><span>🎁</span> Rewards</h3>
          <div className="flex flex-wrap gap-2">{selected.rewards.map((r, i) => <span key={i} className="text-xs px-3 py-1.5 rounded-lg bg-aurora-card border border-aurora-border text-emerald-400">{r}</span>)}</div>
        </div>
        <div className="mb-6">
          <h3 className="text-lg font-bold text-cyan-400 mb-3 font-cinzel flex items-center gap-2"><span>🗺️</span> Walkthrough</h3>
          <ol className="space-y-2">
            {selected.walkthrough.map((step, i) => (
              <li key={i} className="flex gap-3 bg-aurora-card border border-aurora-border rounded-lg p-3 hover:border-violet-500/15 transition-colors">
                <span className="w-7 h-7 rounded-full bg-violet-500/15 text-violet-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">{i + 1}</span>
                <span className="text-gray-300 text-sm leading-relaxed">{step}</span>
              </li>
            ))}
          </ol>
        </div>
        <div>
          <h3 className="text-lg font-bold text-cyan-400 mb-3 font-cinzel flex items-center gap-2"><span>💡</span> Tips</h3>
          <div className="grid gap-2">{selected.tips.map((t, i) => <div key={i} className="flex items-start gap-3 bg-aurora-card border border-aurora-border rounded-lg p-3"><span className="text-cyan-500 mt-0.5 shrink-0">▸</span><span className="text-gray-300 text-sm">{t}</span></div>)}</div>
        </div>
        {/* Wiki link */}
        <div className="mt-6 text-center">
          <a href={`https://runescape.wiki/w/${selected.name.replace(/ /g, '_')}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm text-cyan-500 hover:text-cyan-400 transition-colors">
            📖 Full guide on RS Wiki ↗
          </a>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div className="flex bg-aurora-deep rounded-xl p-1 border border-aurora-border">
          <button onClick={() => { setTab('free'); setDiff('All'); setSearch(''); }} className={`px-5 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${tab === 'free' ? 'bg-emerald-600/12 text-emerald-400 border border-emerald-500/25' : 'text-gray-400 hover:text-white'}`}>
            <span className="flex items-center gap-2">🆓 F2P <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500">{getF2PQuests().length}</span></span>
          </button>
          <button onClick={() => { setTab('members'); setDiff('All'); setSearch(''); }} className={`px-5 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${tab === 'members' ? 'bg-violet-600/12 text-violet-400 border border-violet-500/25' : 'text-gray-400 hover:text-white'}`}>
            <span className="flex items-center gap-2">⭐ Members <span className="text-xs px-2 py-0.5 rounded-full bg-violet-500/10 text-violet-500">{getMembersQuests().length}</span></span>
          </button>
        </div>
        <div className="relative w-full sm:w-64">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search quests..." className="w-full bg-aurora-deep border border-aurora-border rounded-xl pl-10 pr-4 py-2.5 text-white text-sm placeholder-gray-600 focus:outline-none focus:border-cyan-500/40 transition-colors" />
        </div>
      </div>
      <div className={`rounded-xl p-4 mb-6 border aurora-shimmer ${tab === 'free' ? 'bg-emerald-500/[0.02] border-emerald-500/12' : 'bg-violet-500/[0.02] border-violet-500/12'}`}>
        {tab === 'free' ? (
          <div><h2 className="text-base font-bold text-emerald-400 mb-1 font-cinzel">F2P Quests</h2><p className="text-sm text-gray-400">Available to all players. Total QP: {getF2PQuests().reduce((s, q) => s + q.questPoints, 0)}. Complete these for XP, areas, and abilities.</p></div>
        ) : (
          <div><h2 className="text-base font-bold text-violet-400 mb-1 font-cinzel">Members Quests</h2><p className="text-sm text-gray-400">Members-only with richer stories and essential unlocks like Prifddinas, Ancient Magicks, and Ancient Curses.</p></div>
        )}
      </div>
      <div className="flex flex-wrap gap-2 mb-4">
        {availDiffs.map(d => <button key={d} onClick={() => setDiff(d)} className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${diff === d ? 'bg-cyan-500/12 text-cyan-400 border border-cyan-500/25' : 'bg-aurora-card text-gray-400 border border-aurora-border hover:text-white hover:border-aurora-border-light'}`}>{d}</button>)}
      </div>
      <p className="text-xs text-gray-600 mb-3">Showing {filtered.length} quests</p>
      {filtered.length > 0 ? (
        <div className="grid gap-3">
          {filtered.map(q => (
            <button key={q.id} onClick={() => setSelected(q)} className="group bg-aurora-card border border-aurora-border rounded-xl p-4 text-left hover:border-violet-500/30 hover:shadow-lg hover:shadow-violet-500/5 transition-all cursor-pointer w-full">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-violet-500/8 border border-violet-500/15 flex items-center justify-center text-xl shrink-0 group-hover:scale-110 transition-transform">📜</div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="text-white font-semibold">{q.name}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${diffColors[q.difficulty]}`}>{q.difficulty}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-white/5 text-gray-400">{q.questPoints} QP</span>
                    {q.seriesTag && <span className="text-xs px-2 py-0.5 rounded-full bg-violet-500/8 text-violet-300">{q.seriesTag}</span>}
                  </div>
                  <p className="text-gray-500 text-xs line-clamp-2 mb-2">{q.description}</p>
                  <span className="text-xs text-gray-600">{q.length} • {q.skills.length > 0 ? q.skills.slice(0, 3).join(', ') + (q.skills.length > 3 ? '…' : '') : 'No reqs'}</span>
                </div>
                <svg className="w-5 h-5 text-gray-600 group-hover:text-violet-400 transition-colors shrink-0 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="text-center py-16"><div className="text-4xl mb-4">🔍</div><h3 className="text-lg font-semibold text-gray-300 mb-2">No quests found</h3></div>
      )}
    </>
  );
}
